
#png(filename = "SamplePurity.png", width=800, height=600);
pdf("SamplePurity.pdf", width=4, height=4);
setwd('results/');
t=read.table("t.00pN.res.txt");
plot(t$V1, x=rep(0, NROW(t$V1)), xlim=c(0, 1), ylim=c(0, 1), pch=16, col="#00000050", xlab="Normal Contamination", ylab="Estimated Normal Contamination", main="SNUC Cell-line Gradient");
points(max(t$V1), x=0, col="red", pch=4);
est=c(max(t$V1));

t=read.table("t.05pN.res.txt")
points(t$V1, x=rep(0.05, NROW(t$V1)), xlim=c(0, 1), ylim=c(0, 1), pch=16, col="#00000050");
points(max(t$V1), x=0.05, col="red", pch=4);
est=c(est, max(t$V1));

t=read.table("t.10pN.res.txt")
points(t$V1, x=rep(0.1, NROW(t$V1)), xlim=c(0, 1), ylim=c(0, 1), pch=16, col="#00000050");
points(max(t$V1), x=0.1, col="red", pch=4);
est=c(est, max(t$V1));

t=read.table("t.20pN.res.txt")
points(t$V1, x=rep(0.2, NROW(t$V1)), xlim=c(0, 1), ylim=c(0, 1), pch=16, col="#00000050");
points(max(t$V1), x=0.2, col="red", pch=4);
est=c(est, max(t$V1));

t=read.table("t.30pN.res.txt")
points(t$V1, x=rep(0.3, NROW(t$V1)), xlim=c(0, 1), ylim=c(0, 1), pch=16, col="#00000050");
points(max(t$V1), x=0.3, col="red", pch=4);
est=c(est, max(t$V1));

t=read.table("t.40pN.res.txt")
points(t$V1, x=rep(0.4, NROW(t$V1)), xlim=c(0, 1), ylim=c(0, 1), pch=16, col="#00000050");
points(max(t$V1), x=0.4, col="red", pch=4);
est=c(est, max(t$V1));

t=read.table("t.50pN.res.txt")
points(t$V1, x=rep(0.5, NROW(t$V1)), xlim=c(0, 1), ylim=c(0, 1), pch=16, col="#00000050");
points(max(t$V1), x=0.5, col="red", pch=4);
est=c(est, max(t$V1));

t=read.table("t.60pN.res.txt")
points(t$V1, x=rep(0.6, NROW(t$V1)), xlim=c(0, 1), ylim=c(0, 1), pch=16, col="#00000050");
points(max(t$V1), x=0.6, col="red", pch=4);
est=c(est, max(t$V1));

t=read.table("t.70pN.res.txt")
points(t$V1, x=rep(0.7, NROW(t$V1)), xlim=c(0, 1), ylim=c(0, 1), pch=16, col="#00000050");
points(max(t$V1), x=0.7, col="red", pch=4);
est=c(est, max(t$V1));

t=read.table("t.80pN.res.txt")
points(t$V1, x=rep(0.8, NROW(t$V1)), xlim=c(0, 1), ylim=c(0, 1), pch=16, col="#00000050");
points(max(t$V1), x=0.8, col="red", pch=4);
est=c(est, max(t$V1));

t=read.table("t.90pN.res.txt")
points(t$V1, x=rep(0.9, NROW(t$V1)), xlim=c(0, 1), ylim=c(0, 1), pch=16, col="#00000050");
points(max(t$V1), x=0.9, col="red", pch=4);
est=c(est, max(t$V1));

abline(a=0, b=1, col="#FF000030");

dev.off();
