#!/bin/sh

. ../setup.sh

counter=1
for i in segs/*.txt; do
	base_name=${i##*/};
	base_name=${base_name%%.seg.txt}
	if [ $counter -gt 7 ]; then
		thr=0.03
		len=1000000
	else
		thr=0.05
		len=1000000
	fi
	$SST_SEGTXT2DB -t $thr -m 1 -e $len $i clusters/$base_name.sqlite > /dev/null 2>&1
	$SST_MAIN clusters/$base_name.sqlite subclones/$base_name.sqlite 2>&1 | grep Viable | cut -f2 -d: | cut -f1 -d, > results/$base_name.res.txt
	echo "Sample $counter processed"
	counter=`expr $counter + 1`
done
