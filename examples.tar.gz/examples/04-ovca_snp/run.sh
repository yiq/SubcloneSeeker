#!/bin/sh

. ../setup.sh

mkdir -p results/clusters results/subclones

for file in samples/*; do
	SAMPLE=${file##*/}
	$SXT_AML2DB $file 2>/dev/null
	mv samples/*.sqlite results/clusters/
	$SST_MAIN results/clusters/$SAMPLE-pri.sqlite results/subclones/$SAMPLE-pri.sqlite >/dev/null 2>&1
	$SST_MAIN results/clusters/$SAMPLE-rel.sqlite results/subclones/$SAMPLE-rel.sqlite >/dev/null 2>&1

	echo "SAMPLE $SAMPLE"
	$SST_TM results/subclones/$SAMPLE-pri.sqlite results/subclones/$SAMPLE-rel.sqlite 2>/dev/null
done
