#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifndef HAVE_SRANDDEV
#include <ctime>
#endif

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <getopt.h>
#include "RefGenome.h"

#include "Archivable.h"
#include "SegmentalMutation.h"
#include "EventCluster.h"
#include "Subclone.h"

#define MUT_LINEAR 0
#define MUT_RANDOM 1
#define MUT_PROB 2

#define GENOMIC_RESOLUTION 10000

static const char *_prog_name;
static int _n_subclones;
static int _mut_model;
static int _mut_per_subclone;
static double _resolution;

void usage()
{
	std::cout<<"Usage: "<<_prog_name<<" [options]"<<std::endl;
	std::cout<<"\t\t -n <number of subclones to simulate>"<<std::endl;
	std::cout<<"\t\t -m <0|1|2> simulation model"<<std::endl;
	std::cout<<"\t\t -p <number of mutations per subclone>"<<std::endl;
	std::cout<<"\t\t -r <minimal resolution, 0-1>"<<std::endl;
}

void sim_main();
using namespace SubcloneSeeker;

int main(int argc, char* argv[])
{

#ifdef HAVE_SRANDDEV
	sranddev();
#else
	srand(time(NULL));
#endif

	_prog_name = argv[0];
	_n_subclones = 0;
	_mut_model = 0;
	_mut_per_subclone = 1;
	_resolution = 0.1;
	int c;
	while(( c = getopt(argc, argv, "n:m:p:r:h") ) != -1) {
		switch(c) {
			case 'n':
				_n_subclones = atoi(optarg); break;
			case 'm':
				_mut_model = atoi(optarg); break;
			case 'p':
				_mut_per_subclone = atoi(optarg); break;
			case 'r':
				_resolution = atof(optarg); break;
			case 'h':
				usage(); exit(0); break;
			default:
				usage(); exit(0); break;
		}
	}

	if(_n_subclones <= 0) {
		usage(); exit(0);
	}

	std::cerr<<"num of clones: "<<_n_subclones<<std::endl;
	std::cerr<<"model: "<<_mut_model<<std::endl;
	std::cerr<<"mutation per subclone: "<<_mut_per_subclone<<std::endl;

	sim_main();

	return 0;
}


class UpdateFractionTreeTraverser : public TreeTraverseDelegate
{
	protected:
		double _sumFrac;
	protected:
		void processNode(TreeNode * node) {
			Subclone *snode = dynamic_cast<Subclone *>(node);
			snode->setFraction(snode->fraction() / _sumFrac);

			if(snode->isLeaf()) {
				snode->setTreeFraction(snode->fraction());
			}
			else {
				double childrenFrac = 0;
				for(size_t i=0; i<snode->getVecChildren().size(); i++)
					childrenFrac += dynamic_cast<Subclone *>(snode->getVecChildren()[i])->treeFraction();
				snode->setTreeFraction(childrenFrac + snode->fraction());
			}

			for(size_t i=0; i<snode->vecEventCluster().size(); i++)
				snode->vecEventCluster()[i]->setCellFraction(snode->treeFraction());
		}
	public:
		UpdateFractionTreeTraverser(double sumFrac):TreeTraverseDelegate(), _sumFrac(sumFrac) {;}
};

class PrintStructureTraverser : public TreeTraverseDelegate
{
	protected:
		void preprocessNode(TreeNode * node) {
			if(node->getVecChildren().size() > 0)
				std::cout<<"(";
		}

		void processNode(TreeNode * node) {
			Subclone *snode = dynamic_cast<Subclone *>(node);
			std::cout<<snode->fraction();
			std::cout<<",";
		}

		void postprocessNode(TreeNode * node) {
			if(node->getVecChildren().size() > 0)
				std::cout<<")";
		}
};

void sim_main() {

	// stage 1, random tree generation
	Subclone *root = new Subclone();
	std::vector<Subclone *> vecClones;
	std::vector<double> vecFraction;
	std::vector<CNV*> vecEvents;

	double sumFrac = 100;

	vecClones.push_back(root);
	vecFraction.push_back(100);
	root->setFraction(100);

	for(size_t i=0; i<_n_subclones; i++) {

		Subclone *parent;
		double cumulativeFrac = 0;
		int rand_choice;
		parent = root;

		// select parent
		switch(_mut_model) {
			case MUT_LINEAR:
				parent = vecClones[vecClones.size()-1];
				break;
			case MUT_RANDOM:
				parent = vecClones[rand() % vecClones.size()];
				break;
			case MUT_PROB:
				rand_choice = rand() % 100;
				for(size_t j=0; j<vecClones.size(); j++) {
					parent = vecClones[j];

					if(cumulativeFrac * 100 > rand_choice) {
						break;
					}

					cumulativeFrac += (vecFraction[j] / sumFrac);
				}
				break;
			default:
				std::cerr<<"Undefined parent clone selection mode"<<std::endl;
				abort();
		}

		double new_frac = rand() % ((int)ceil(parent->fraction() * 2 - parent->fraction() / 2)) + parent->fraction()/2;

		// spawn new clone
		Subclone *child = new Subclone();

		// generate mutations
		EventCluster *cluster = new EventCluster();
		static int mut_counter = 1;

		for(size_t j=0; j<_mut_per_subclone; j++) {

			CNV *cnv = new CNV();
			cnv->range.chrom = mut_counter++;
			cnv->range.position = 1000;
			cnv->range.length = 1000;

			cnv->frequency=new_frac;

			cluster->addEvent(cnv);
			vecEvents.push_back(cnv);
		}

		parent->addChild(child);
		vecClones.push_back(child);

		child->addEventCluster(cluster);

		vecFraction.push_back(new_frac);
		child->setFraction(new_frac);
		sumFrac+=new_frac;
	}

	// update fraction
	UpdateFractionTreeTraverser uftt(sumFrac);
	TreeNode::PostOrderTraverse(root, uftt);

	sqlite3 *database;
	sqlite3_open("archive.sqlite", &database);

	PrintStructureTraverser pst;
	TreeNode::PreOrderTraverse(root, pst);
	std::cout<<std::endl;
	TreeNode::PostOrderTraverse(root, pst);
	std::cout<<std::endl;

	SubcloneSaveTreeTraverser sst(database);
	TreeNode::PreOrderTraverse(root, sst);

	sqlite3_close(database);

}
