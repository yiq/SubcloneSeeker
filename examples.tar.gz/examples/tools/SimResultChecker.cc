#include <iostream>
#include <cmath>
#include <algorithm>
#include <sqlite3/sqlite3.h>

#include "GenomicLocation.h"
#include "EventCluster.h"
#include "TreeNode.h"
#include "Subclone.h"

#define RET_OK 0
#define RET_NOT_FOUND 1
#define RET_MULTIPLE_FOUND 2
#define RET_ERROR_USAGE 4
#define RET_ERROR_SIMDB 5
#define RET_ERROR_RESDB 6
#define RET_ERROR_NOSIMCLONE 7
#define RET_ERROR_MULTISIMCLONE 8
#define RET_ERROR_NORESCLONE 9

#define EPISLON 1e-3

using namespace SubcloneExplorer;

bool check_close(double d1, double d2) {
	double diff = fabs(d1-d2);
	if(diff > EPISLON)
		return false;
	return true;
}

bool subcloneCompare(TreeNode *c1, TreeNode *c2) {
	return (dynamic_cast<Subclone*>(c1))->fraction() < (dynamic_cast<Subclone*>(c2))->fraction();
}
bool subcloneEqual(Subclone *tree1, Subclone *tree2);

int main(int argc, char* argv[]) {
	if(argc<2) {
		std::cout<<"Usage: "<<argv[0]<<" <sim-out.sqlite> <exp-out.sqlite>"<<std::endl;
		return(RET_ERROR_USAGE);
	}

	sqlite3 *sim_db;
	sqlite3 *res_db;

	int rc;

	/***** OPEN DATABASE *****/
	
	rc = sqlite3_open_v2(argv[1], &sim_db, SQLITE_OPEN_READONLY, NULL);
	if(rc != SQLITE_OK) {
		std::cerr<<"Unable to open simulation database "<<argv[1]<<std::endl;
		return(RET_ERROR_SIMDB);
	}

	rc = sqlite3_open_v2(argv[2], &res_db, SQLITE_OPEN_READONLY, NULL);
	if(rc != SQLITE_OK) {
		std::cerr<<"Ubable to open result database "<<argv[2]<<std::endl;
		return(RET_ERROR_RESDB);
	}


	/***** LOAD TRUE STRUCTURE FROM SIMULATION DATABASE *****/
	std::vector<sqlite3_int64> roots = SubcloneLoadTreeTraverser::rootNodes(sim_db);

	if(roots.size() != 1) {
		if(roots.size() < 1) {
			std::cerr<<"No simulated subclonal structure is found in the simulation database"<<std::endl;
			return(RET_ERROR_NOSIMCLONE);
		}
		else {
			std::cerr<<"More than one simulated subclonal structures are found in the simulation database"<<std::endl;
			return(RET_ERROR_MULTISIMCLONE);
		}
	}

	SubcloneLoadTreeTraverser simLoadTraverser(sim_db);
	Subclone *trueRoot = new Subclone();
	trueRoot->unarchiveObjectFromDB(sim_db, roots[0]);
	TreeNode::PreOrderTraverse(trueRoot, simLoadTraverser);

	sqlite3_close(sim_db);

	/***** LOAD ALL SOLUTION TREES *****/
	std::vector<sqlite3_int64> solutions = SubcloneLoadTreeTraverser::rootNodes(res_db);
	SubcloneLoadTreeTraverser solutionLoadTraverser(res_db);
	
	if(solutions.size() == 0) {
		std::cerr<<"No solution is present in the result database"<<std::endl;
		return(RET_ERROR_NORESCLONE);
	}

	size_t subclonesFound = 0;

	for(size_t i=0; i<solutions.size(); i++) {
		Subclone * aSolution = new Subclone();
		aSolution->unarchiveObjectFromDB(res_db, solutions[i]);
		TreeNode::PreOrderTraverse(aSolution, solutionLoadTraverser);
		if(subcloneEqual(aSolution, trueRoot)) {
			std::cerr<<"Same subclone found: "<<aSolution->getId()<<std::endl;
			subclonesFound++;
		}
	}

	sqlite3_close(res_db);
	std::cerr<<"Comparison finished, subclones found="<<subclonesFound<<std::endl;

	if(subclonesFound == 0) {
		return(RET_NOT_FOUND);
	}
	else if(subclonesFound > 1) {
		return(RET_MULTIPLE_FOUND);
	}
	
	return RET_OK;
}


bool subcloneEqual(Subclone *tree1, Subclone *tree2) {
	if(tree1 == NULL || tree2 == NULL) {
		std::cerr<<"NULL Pointer Fail"<<std::endl;
		return false;
	}

	if(!check_close(tree1->fraction(), tree2->fraction())) {
		std::cerr<<"Fraction Fail: " << tree1->fraction() <<" <> " << tree2->fraction()<<std::endl;
		return false;
	}

	if(!tree1->isLeaf()) {
		if(tree2->isLeaf()) {
			std::cerr<<"tree2 isLeaf Fail"<<std::endl;
			return false;
		}
		std::vector<TreeNode *> children1 = tree1->getVecChildren();
		std::vector<TreeNode *> children2 = tree2->getVecChildren();

		if(children1.size() != children2.size()) {
			std::cerr<<"children size fail: "<<children1.size()<<" <> "<<children2.size()<<std::endl;
			return false;
		}

		sort(children1.begin(), children1.end(), subcloneCompare);
		sort(children2.begin(), children2.end(), subcloneCompare);

		for(size_t i=0; i<children1.size(); i++) {
			if( not subcloneEqual(dynamic_cast<Subclone *>(children1[i]), dynamic_cast<Subclone *>(children2[i]))) {
				std::cerr<<"subtree fail"<<std::endl;
					return false;
			}
		}
	}
	else {
		if(!tree2->isLeaf()) {
			std::cerr<<"Tree2 is not leaf Fail"<<std::endl;
			return false;
		}
	}

	std::cerr<<std::endl;

	return true;
}
