plot_stat_2 <- function(n) {
	stat=read.table('stat', header=F);
	hist(stat$V1, xlab="Number of viable structures", ylab="Count", main=paste(n, "subclones"), xlim=c(1, factorial(n)), breaks=50);
	return(stat$V1);
}

par(mfrow=c(2, 3));

for(i in 3:8) {
	setwd(paste("results/", i, sep=""));
	data = plot_stat_2(i);
	print(quantile(data, 0.95))
	setwd("../..");
}
