#!/bin/sh

. ../setup.sh
SIMS_PER_CASE=100
MAJOR_TICK=`expr $SIMS_PER_CASE / 20`
MINOR_TICK=`expr $SIMS_PER_CASE / 100`
if [ -d results ]; then
	rm -rf results
fi

mkdir results
cd results
for n_clone in {3..8}; do
	mkdir $n_clone
	cd $n_clone
	echo "Running $SIMS_PER_CASE simulation with $n_clone subclones"
	time for i in $(seq 1 $SIMS_PER_CASE); do 
		$SXT_SUBCSIM -n $n_clone -m 2 >>sim.out 2>>sim.err 
		mv archive.sqlite arc-$i.sqlite 
		$SST_MAIN arc-$i.sqlite res-$i.sqlite >>stat 2>>stexp.err
		$SXT_SIMCHECKER arc-$i.sqlite res-$i.sqlite >> checker.out 2>>checker.err
		echo $i: $? >> log 

		Tick=`expr $i % $MAJOR_TICK`
		minTick=`expr $i % $MINOR_TICK`

		if [ $Tick -eq 0 ]; then
			percent=`expr $i / $MINOR_TICK`
			printf "$percent%%"
		elif [ $minTick -eq 0 ]; then
			printf "."
		fi
	done
	echo ""
	cd ..
done
cd ..
