#!/bin/sh

# This file contains some variables pointing to the path
# of the SubcloneSeeker main project and the example directory
#
# Also there are some scripts to check if the required binaries are
# present, build the tools needed by the examples if they are not found
# and export the path of the binaries in various variables.

# Please modify the path accordingly, but do not run this script by hand,
# as the script will be automatically included when you run the individual
# examples.

# The base path where the SubcloneSeeker main project is located
SSHOME=

# The path where the example folder is
SSEX=$SSHOME/examples



#----------------------------------------------------------------------#
#------------------ NO NOT MODIFY AFTER THIS LINE ---------------------#
#----------------------------------------------------------------------#

export SSHOME SSEX

# Check the existance of the SSHOME directory
if [ ! -d $SSHOME ]; then
	echo "The given path $SSHOME does not exist, or is not a directory. Please double check"
	exit 1
fi

# Check the existance of binaries
if [ ! -e $SSHOME/utils/ssmain ]; then
	echo "The SubcloneSeeker project is not properly built. $SSHOME/utils/ssmain is missing. Please double check"
	exit 1
else
	SST_MAIN=$SSHOME/utils/ssmain
fi

if [ ! -e $SSHOME/utils/treemerge ]; then
	echo "The SubcloneSeeker project is not properly built. $SSHOME/utils/treemerge is missing. Please double check"
	exit 1
else
	SST_TM=$SSHOME/utils/treemerge
fi

if [ ! -e $SSHOME/utils/segtxt2db ]; then
	echo "The SubcloneSeeker project is not properly built. $SSHOME/utils/segtxt2db is missing. Please double check"
	exit 1
else
	SST_SEGTXT2DB=$SSHOME/utils/segtxt2db
fi

# Check the existance of tool binaries
if [ ! -e $SSEX/tools/aml2db -o ! -e $SSEX/tools/SubcSim -o ! -e $SSEX/tools/SimResultChecker ]; then
	printf "Building tools needed by the examples..."
	OLDPWD=$PWD
	cd $SSEX/tools
	make > build.log.out 2>build.log.err
	if [ $? -gt 0 ]; then
		echo "Error occurred in building for the example tools, see $SSEX/tools/build.log.out and $SSEX/tools/build.log.err for details"
		exit 1
	fi
	rm build.log.out
	rm build.log.err

	cd $OLDPWD
	printf "done\n"
fi

SXT_AML2DB=$SSEX/tools/aml2db
SXT_SUBCSIM=$SSEX/tools/SubcSim
SXT_SIMCHECKER=$SSEX/tools/SimResultChecker
